import React from 'react';
import { Server, Database, Globe, Shield, Cpu, Zap } from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';
import CurrencySwitch from '../components/CurrencySwitch';

const HostingPage: React.FC = () => {
  const { currency } = useCurrency();

  const formatPrice = (price: number) => {
    if (currency.code === 'INR') {
      const inrPrice = price * currency.multiplier;
      return `${currency.symbol}${Math.round(inrPrice)}`;
    }
    return `$${price.toFixed(2)}`;
  };

  const hostingTypes = [
    {
      icon: Server,
      title: 'Personal',
      description: 'Perfect for small to medium websites',
      originalPrice: 14.99,
      price: 2.99,
      features: ['1 Website', '10 GB SSD Raid Storage', 'Up to 25K Monthly Visitors', 'Free SPanel', 'Automatic Malware Scans'],
    },
    {
      icon: Database,
      title: 'Business',
      description: 'Full control and dedicated resources',
      originalPrice: 29.99,
      price: 5.99,
      features: ['100 Websites', '30 GB SSD Raid Storage', 'Up to 50K Monthly Visitors', 'Unlimited Bandwidth', 'Unlimited Mail Accounts'],
      highlighted: true,
    },
    {
      icon: Globe,
      title: 'Enterprise',
      description: 'Maximum performance and security',
      originalPrice: 49.99,
      price: 9.99,
      features: ['300 Websites', '100 GB SSD Storage', 'Up to 100K Monthly Visitors', 'Website Backup Protection', 'Automatic Malware Scans', 'Free Domain'],
    },
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-block mb-6 bg-black/20 backdrop-blur-sm px-6 py-2 rounded-full text-indigo-100">
              🔥 BLACK FRIDAY SALE: 80% OFF + 3 MONTHS FREE
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Professional Web Hosting Solutions
            </h1>
            <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
              Choose the perfect hosting solution for your website. From shared hosting to dedicated servers, we've got you covered.
            </p>
            <div className="flex justify-center">
              <CurrencySwitch />
            </div>
          </div>
        </div>
      </section>

      {/* Hosting Types */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Black Friday Special Offers</h2>
            <p className="text-gray-600">
              Limited time offer - Save 80% on all plans + get 3 months free!
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {hostingTypes.map((type) => (
              <div 
                key={type.title} 
                className={`relative bg-white rounded-xl p-8 transition-transform hover:scale-105 ${
                  type.highlighted ? 'shadow-2xl ring-2 ring-indigo-600' : 'shadow-xl'
                }`}
              >
                {type.highlighted && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                      Most Popular
                    </span>
                  </div>
                )}

                <type.icon className="h-12 w-12 text-indigo-600 mb-6" />
                <h3 className="text-2xl font-bold mb-4">{type.title}</h3>
                <p className="text-gray-600 mb-6">{type.description}</p>
                
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm line-through opacity-70">
                      {formatPrice(type.originalPrice)}/mo
                    </span>
                    <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                      -80%
                    </span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-indigo-600">
                      {formatPrice(type.price)}
                    </span>
                    <span className="text-gray-500">/month</span>
                  </div>
                  <div className="mt-1 text-sm text-emerald-500 font-medium">
                    + 3 Months Free
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {type.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-700">
                      <span className="h-1.5 w-1.5 bg-indigo-600 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>

                <a
                  href="https://ixyhosting.com/whmcs/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors text-center"
                >
                  Claim Deal Now
                </a>

                <p className="text-center mt-4 text-sm text-gray-500">
                  Offer ends November 27, 2024
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Advanced Features Included</h2>
            <p className="text-gray-600">All hosting plans come with these powerful features to ensure your success</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: 'Advanced Security',
                description: 'Free SSL certificates and DDoS protection included with all plans',
              },
              {
                icon: Cpu,
                title: 'High Performance',
                description: 'Powered by latest Intel processors and NVMe SSDs',
              },
              {
                icon: Globe,
                title: 'Global CDN',
                description: 'Lightning-fast content delivery across 200+ locations',
              },
              {
                icon: Zap,
                title: 'One-Click Apps',
                description: 'Install popular apps and CMS with a single click',
              },
              {
                icon: Server,
                title: 'Daily Backups',
                description: 'Automated backups to keep your data safe',
              },
              {
                icon: Shield,
                title: '24/7 Support',
                description: 'Expert support available around the clock',
              },
            ].map((feature, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <feature.icon className="h-10 w-10 text-indigo-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HostingPage;