import React from 'react';
import { useWhmcs } from '../hooks/useWhmcs';
import { User, Package, FileText, Settings } from 'lucide-react';
import WhmcsIntegration from '../components/WhmcsIntegration';

const ClientArea: React.FC = () => {
  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="space-y-2">
                <button className="w-full flex items-center gap-3 px-4 py-2 text-left rounded-lg hover:bg-indigo-50 text-indigo-600">
                  <User className="h-5 w-5" />
                  <span>My Profile</span>
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-2 text-left rounded-lg hover:bg-indigo-50 text-gray-600">
                  <Package className="h-5 w-5" />
                  <span>Services</span>
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-2 text-left rounded-lg hover:bg-indigo-50 text-gray-600">
                  <FileText className="h-5 w-5" />
                  <span>Invoices</span>
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-2 text-left rounded-lg hover:bg-indigo-50 text-gray-600">
                  <Settings className="h-5 w-5" />
                  <span>Settings</span>
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3 space-y-8">
            <WhmcsIntegration />
            
            {/* Active Services */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold mb-6">Active Services</h3>
              <div className="space-y-4">
                {[1, 2].map((service) => (
                  <div key={service} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold">Business Hosting Plan</h4>
                        <p className="text-sm text-gray-600">Next renewal: March 15, 2024</p>
                      </div>
                      <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                        Active
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Invoices */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold mb-6">Recent Invoices</h3>
              <div className="space-y-4">
                {[1, 2].map((invoice) => (
                  <div key={invoice} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-semibold">Invoice #1001{invoice}</h4>
                        <p className="text-sm text-gray-600">Due: March 1, 2024</p>
                      </div>
                      <span className="text-lg font-semibold text-indigo-600">$29.99</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientArea;