import React, { useState } from 'react';
import { usePostsByCategory, useCategories } from '../hooks/useWordPress';
import { Loader2 } from 'lucide-react';
import BlogPost from '../components/BlogPost';
import { useSearchParams } from 'react-router-dom';

const BlogPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const slug = searchParams.get('post');
  const [selectedCategory, setSelectedCategory] = useState<number>();
  const { data: posts, isLoading, error } = usePostsByCategory(selectedCategory);
  const { data: categories } = useCategories();

  if (slug) {
    return (
      <div className="pt-20 min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <BlogPost slug={slug} />
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Error Loading Posts</h2>
          <p className="text-gray-600">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Latest Updates</h1>
          <p className="text-xl text-gray-600">Stay informed with our latest news and insights</p>
        </div>

        {/* Categories */}
        {categories && (
          <div className="flex flex-wrap gap-2 mb-8">
            <button
              onClick={() => setSelectedCategory(undefined)}
              className={`px-4 py-2 rounded-full text-sm ${
                !selectedCategory
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Posts
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm ${
                  selectedCategory === category.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        )}

        {/* Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts?.map((post) => (
            <article key={post.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="p-6">
                <h2 
                  className="text-xl font-bold mb-2 hover:text-indigo-600 transition-colors" 
                  dangerouslySetInnerHTML={{ __html: post.title.rendered }} 
                />
                <div className="text-gray-600 mb-4 text-sm">
                  {new Date(post.date).toLocaleDateString()}
                </div>
                <div 
                  className="prose prose-sm mb-4"
                  dangerouslySetInnerHTML={{ __html: post.excerpt.rendered }} 
                />
                <a 
                  href={`/blog?post=${post.slug}`}
                  className="inline-flex items-center text-indigo-600 font-medium hover:text-indigo-700"
                >
                  Read More
                  <svg className="ml-2 w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;