import React from 'react';
import { Globe2, Shield, RefreshCw } from 'lucide-react';
import DomainSearch from '../components/DomainSearch';

const DomainPage: React.FC = () => {
  return (
    <div className="pt-16 sm:pt-20 min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-purple-600 py-12 sm:py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4 sm:mb-6">
            Find Your Perfect Domain Name
          </h1>
          <p className="text-lg sm:text-xl text-indigo-100 max-w-2xl mx-auto">
            Secure your online presence with a domain name that represents your brand
          </p>
        </div>
      </section>

      {/* Domain Search Section */}
      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <DomainSearch />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <Globe2 className="h-12 w-12 text-indigo-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Global DNS</h3>
              <p className="text-gray-600">
                Fast and reliable DNS infrastructure across multiple continents
              </p>
            </div>
            <div className="text-center p-6">
              <Shield className="h-12 w-12 text-indigo-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Domain Protection</h3>
              <p className="text-gray-600">
                Free WHOIS privacy and advanced security features included
              </p>
            </div>
            <div className="text-center p-6">
              <RefreshCw className="h-12 w-12 text-indigo-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Auto-Renewal</h3>
              <p className="text-gray-600">
                Never worry about domain expiration with automatic renewals
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-2">
                How do I transfer my domain?
              </h3>
              <p className="text-gray-600">
                Transferring your domain is simple. Just unlock your domain at your current registrar, get the authorization code, and start the transfer process with us.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-2">
                What's included with domain registration?
              </h3>
              <p className="text-gray-600">
                All domain registrations include free WHOIS privacy protection, DNS management, email forwarding, and automatic renewal options.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-2">
                How long can I register a domain for?
              </h3>
              <p className="text-gray-600">
                You can register domains for 1 to 10 years. Longer registrations can help establish trust with search engines and customers.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DomainPage;