import React from 'react';
import { Check, ArrowRight, Zap } from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';
import CountdownTimer from '../components/CountdownTimer';
import { useCountdownDates } from '../hooks/useCountdownDates';

const BlackFridayPage: React.FC = () => {
  const { currency } = useCurrency();
  const countdownDates = useCountdownDates();

  const formatPrice = (price: number) => {
    if (currency.code === 'INR') {
      return `₹${Math.round(price * currency.multiplier)}`;
    }
    return `$${price.toFixed(2)}`;
  };

  const plans = [
    {
      name: 'Basic Hosting',
      originalPrice: 9.99,
      features: [
        '1 Website',
        '10 GB SSD Storage',
        'Free SSL Certificate',
        'Free Domain (1st Year)',
        'Daily Backups'
      ]
    },
    {
      name: 'Pro WordPress',
      originalPrice: 19.99,
      features: [
        '5 Websites',
        '30 GB SSD Storage',
        'Free SSL Certificate',
        'Free Domain (1st Year)',
        'Daily Backups',
        'Staging Environment',
        'LiteSpeed Cache'
      ],
      popular: true
    },
    {
      name: 'Enterprise',
      originalPrice: 39.99,
      features: [
        'Unlimited Websites',
        '100 GB SSD Storage',
        'Free SSL Certificate',
        'Free Domain (1st Year)',
        'Daily Backups',
        'Staging Environment',
        'LiteSpeed Cache',
        'Redis Cache',
        'Priority Support'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-20">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-800 to-indigo-900 mix-blend-multiply" />
        </div>
        
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white mb-8">
              BLACK FRIDAY
              <span className="block text-indigo-400">MEGA SALE</span>
            </h1>
            <p className="text-xl sm:text-2xl text-indigo-200 mb-8">
              Save 80% on all hosting plans + 3 months FREE
            </p>
            
            {/* Main Countdown Timer */}
            {countdownDates[0] && (
              <div className="max-w-xl mx-auto mb-8">
                <CountdownTimer 
                  endDate={countdownDates[0]}
                  label="Main Offer Ends In"
                />
              </div>
            )}

            {/* Extended Offer Timers */}
            {countdownDates.length > 1 && (
              <div className="grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto mb-8">
                {countdownDates.slice(1).map((date, index) => (
                  <CountdownTimer
                    key={date.toISOString()}
                    endDate={date}
                    label={`Extended Offer ${index + 1}`}
                    variant="secondary"
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Rest of the BlackFridayPage content remains the same */}
      {/* ... */}
    </div>
  );
};

export default BlackFridayPage;