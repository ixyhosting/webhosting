import React from 'react';
import { Shield, Cpu, Globe2, Zap, Server, Clock, Lock, Cloud, Gauge, HeadphonesIcon } from 'lucide-react';
import DomainSearch from '../components/DomainSearch';
import HostingSlider from '../components/HostingSlider';
import CountdownTimer from '../components/CountdownTimer';
import { useCountdownDates } from '../hooks/useCountdownDates';

const HomePage: React.FC = () => {
  const countdownDates = useCountdownDates();

  return (
    <>
      {/* Hero Section */}
      <section className="pt-16 sm:pt-24 pb-8 sm:pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-4 sm:mb-6">
              Welcome to{' '}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 animate-gradient">
                IXYHosting
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-gray-600 mb-6 sm:mb-8 max-w-2xl mx-auto">
              Lightning-fast servers, unbeatable uptime, and world-class support. Launch your website with confidence.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-3 sm:gap-4">
              <a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-indigo-600 text-white px-6 sm:px-8 py-2.5 sm:py-3 rounded-full hover:bg-indigo-700 transition-colors text-center"
              >
                Get Started
              </a>
              <button className="border border-indigo-600 text-indigo-600 px-6 sm:px-8 py-2.5 sm:py-3 rounded-full hover:bg-indigo-50 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Black Friday Countdown */}
      {countdownDates[0] && (
        <section className="py-8 px-4">
          <div className="max-w-3xl mx-auto">
            <CountdownTimer endDate={countdownDates[0]} label="Black Friday Sale Ends In" />
          </div>
        </section>
      )}

      {/* Domain Search Section */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">Find Your Perfect Domain</h2>
            <p className="text-gray-600">Discover your perfect domain name today</p>
          </div>
          <DomainSearch />
        </div>
      </section>

      {/* Hosting Plans Section */}
      <HostingSlider />

      {/* Features Section */}
      <section className="py-12 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-8 sm:mb-12">Why Choose IXYHosting?</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {[
              { icon: Shield, title: 'Enterprise Security', desc: 'Advanced DDoS protection and SSL certificates included.' },
              { icon: Cpu, title: 'High Performance', desc: 'Powered by latest gen processors and NVMe SSDs.' },
              { icon: Globe2, title: 'Global CDN', desc: 'Content delivery network across 200+ locations.' },
              { icon: Zap, title: 'Instant Deployment', desc: 'Deploy your applications in seconds, not hours.' },
              { icon: Server, title: 'Auto Scaling', desc: 'Resources that grow with your business needs.' },
              { icon: Clock, title: '99.9% Uptime', desc: 'Industry-leading SLA for peace of mind.' },
            ].map((feature, index) => (
              <div key={index} className="p-6 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors">
                <feature.icon className="h-10 w-10 text-indigo-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Features Section */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="prose max-w-none">
            <h2 className="text-3xl font-bold text-center mb-12">Security Features</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">1. Secure Your Files with Automatic Backups and Two-Factor Authentication (2FA)</h3>
                <p className="text-gray-600">Automatic Backups: Set up regular, automated backups to ensure your files and data are consistently saved. This provides peace of mind in case of data loss, system failure, or cyberattacks.</p>
                <p className="text-gray-600 mt-2">Two-Factor Authentication (2FA): Add an extra layer of protection to your online accounts by enabling 2FA. This requires a second form of verification, such as a code sent to your phone or generated by an app.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">2. Encrypt Website Traffic with Unlimited SSL Certificates</h3>
                <p className="text-gray-600">SSL Encryption: Protect your website and its visitors by encrypting data transmitted between them using SSL certificates. SSL ensures that sensitive information, like passwords and payment details, is securely encrypted.</p>
                <p className="text-gray-600 mt-2">Unlimited SSL Certificates: With unlimited SSL certificates, you can secure multiple domains or subdomains under one plan, ensuring that all parts of your online presence are safe.</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">3. Shield Your Website from DDoS Attacks with Cloudflare's Protection</h3>
                <p className="text-gray-600">DDoS Attack Protection: Distributed Denial of Service (DDoS) attacks can overwhelm your website with excessive traffic. Cloudflare offers robust protection against such attacks by filtering malicious traffic.</p>
                <p className="text-gray-600 mt-2">Cloudflare Nameservers: By using Cloudflare's nameservers, you benefit from their global network of security features, reducing downtime and enhancing site speed while protecting your site from threats.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;