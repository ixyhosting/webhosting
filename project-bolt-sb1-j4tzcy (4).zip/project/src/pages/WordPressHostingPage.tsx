import React from 'react';
import { Shield, Zap, Cloud, Server, Globe2, Lock } from 'lucide-react';
import PricingTier from '../components/PricingTier';
import { useCurrency } from '../contexts/CurrencyContext';

const WordPressHostingPage: React.FC = () => {
  const { currency } = useCurrency();

  const formatPrice = (price: number) => {
    if (currency.code === 'INR') {
      return `₹${Math.round(price * currency.multiplier)}`;
    }
    return `$${price.toFixed(2)}`;
  };

  const plans = [
    {
      name: 'Basic',
      description: 'Perfect for small WordPress sites',
      originalPrice: formatPrice(9.99),
      price: formatPrice(1.99), // 80% off
      features: [
        '1 WordPress Installation',
        '10 GB SSD Storage',
        'Free SSL Certificate',
        'Daily Backups',
        'Free Domain (1 year)',
        'LiteSpeed Cache',
      ],
      highlighted: false,
      icon: Server,
    },
    {
      name: 'Pro',
      description: 'Ideal for growing businesses',
      originalPrice: formatPrice(19.99),
      price: formatPrice(3.99), // 80% off
      features: [
        '5 WordPress Installations',
        '30 GB SSD Storage',
        'Free SSL Certificate',
        'Daily Backups',
        'Free Domain (1 year)',
        'LiteSpeed Cache',
        'Staging Environment',
        'Advanced Security',
      ],
      highlighted: true,
      icon: Cloud,
    },
    {
      name: 'Enterprise',
      description: 'For high-traffic WordPress sites',
      originalPrice: formatPrice(39.99),
      price: formatPrice(7.99), // 80% off
      features: [
        'Unlimited WordPress Installations',
        '100 GB SSD Storage',
        'Free SSL Certificate',
        'Daily Backups',
        'Free Domain (1 year)',
        'LiteSpeed Cache',
        'Staging Environment',
        'Advanced Security',
        'Priority Support',
        'Redis Cache',
        'Dedicated Resources',
      ],
      highlighted: false,
      icon: Globe2,
    },
  ];

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-purple-600 py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-block mb-6 bg-black/20 backdrop-blur-sm px-6 py-2 rounded-full text-indigo-100">
            🔥 BLACK FRIDAY SALE: 80% OFF + 3 MONTHS FREE
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            WordPress Hosting Solutions
          </h1>
          <p className="text-xl text-indigo-100 max-w-2xl mx-auto">
            Lightning-fast, secure, and optimized WordPress hosting for your website
          </p>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Black Friday Special Offers</h2>
            <p className="text-gray-600">
              Limited time offer - Save 80% on all plans + get 3 months free!
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <PricingTier key={plan.name} {...plan} />
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-sm text-gray-600">
              * Black Friday offer ends November 27, 2024. Regular prices will apply after the promotional period.
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our WordPress Hosting?</h2>
            <p className="text-gray-600">Experience the best in WordPress hosting technology</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Zap,
                title: 'LiteSpeed Technology',
                description: 'Up to 4x faster than regular WordPress hosting with LiteSpeed Web Server',
              },
              {
                icon: Shield,
                title: 'Advanced Security',
                description: 'Built-in WAF, malware scanning, and DDoS protection',
              },
              {
                icon: Cloud,
                title: 'Auto Scaling',
                description: 'Resources that automatically scale with your traffic needs',
              },
              {
                icon: Lock,
                title: 'Free SSL Certificates',
                description: 'Secure your site with free SSL certificates',
              },
              {
                icon: Server,
                title: 'Daily Backups',
                description: 'Automated daily backups with one-click restore',
              },
              {
                icon: Globe2,
                title: 'Global CDN',
                description: 'Content delivery network included with all plans',
              },
            ].map((feature, index) => (
              <div key={index} className="p-6 bg-gray-50 rounded-xl">
                <feature.icon className="h-10 w-10 text-indigo-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default WordPressHostingPage;