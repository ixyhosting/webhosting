import { z } from 'zod';

export const whmcsConfig = {
  apiEndpoint: import.meta.env.VITE_WHMCS_API_URL || '',
  apiIdentifier: import.meta.env.VITE_WHMCS_IDENTIFIER || '',
  apiSecret: import.meta.env.VITE_WHMCS_SECRET || '',
};

export const WhmcsResponseSchema = z.object({
  result: z.string(),
  message: z.string().optional(),
  totalresults: z.number().optional(),
  products: z.array(z.any()).optional(),
  clients: z.array(z.any()).optional(),
});

export type WhmcsResponse = z.infer<typeof WhmcsResponseSchema>;