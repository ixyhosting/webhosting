import { whmcsConfig } from '../config/whmcs';
import { WhmcsResponse, WhmcsResponseSchema } from '../config/whmcs';

class WhmcsAPI {
  private apiUrl: string;
  private identifier: string;
  private secret: string;

  constructor() {
    this.apiUrl = whmcsConfig.apiEndpoint;
    this.identifier = whmcsConfig.apiIdentifier;
    this.secret = whmcsConfig.apiSecret;
  }

  private async makeRequest(action: string, params: Record<string, any> = {}): Promise<WhmcsResponse> {
    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          identifier: this.identifier,
          secret: this.secret,
          action,
          responsetype: 'json',
          ...params,
        }),
      });

      const data = await response.json();
      return WhmcsResponseSchema.parse(data);
    } catch (error) {
      console.error('WHMCS API Error:', error);
      throw new Error('Failed to communicate with WHMCS');
    }
  }

  async getProducts() {
    return this.makeRequest('GetProducts');
  }

  async getClients() {
    return this.makeRequest('GetClients');
  }

  async createOrder(params: {
    clientid: number;
    pid: number;
    domain?: string;
    billingcycle: string;
  }) {
    return this.makeRequest('AddOrder', params);
  }
}

export const whmcsApi = new WhmcsAPI();