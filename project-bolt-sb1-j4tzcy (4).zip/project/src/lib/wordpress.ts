import { z } from 'zod';

const WP_API_URL = 'https://public-api.wordpress.com/wp/v2/sites/ixyhosting.wordpress.com';

export const PostSchema = z.object({
  id: z.number(),
  title: z.object({
    rendered: z.string(),
  }),
  content: z.object({
    rendered: z.string(),
  }),
  excerpt: z.object({
    rendered: z.string(),
  }),
  date: z.string(),
  modified: z.string(),
  slug: z.string(),
  featured_media: z.number(),
  categories: z.array(z.number()),
  tags: z.array(z.number()),
});

export const CategorySchema = z.object({
  id: z.number(),
  name: z.string(),
  slug: z.string(),
  count: z.number(),
});

export type Post = z.infer<typeof PostSchema>;
export type Category = z.infer<typeof CategorySchema>;

const fetchAPI = async (endpoint: string) => {
  const response = await fetch(`${WP_API_URL}${endpoint}`);
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
};

export const getPosts = async (page = 1, perPage = 9) => {
  const data = await fetchAPI(`/posts?page=${page}&per_page=${perPage}&_embed`);
  return z.array(PostSchema).parse(data);
};

export const getPost = async (slug: string) => {
  const [data] = await fetchAPI(`/posts?slug=${slug}&_embed`);
  return PostSchema.parse(data);
};

export const getCategories = async () => {
  const data = await fetchAPI('/categories');
  return z.array(CategorySchema).parse(data);
};

export const getPostsByCategory = async (categoryId: number, page = 1, perPage = 9) => {
  const data = await fetchAPI(`/posts?categories=${categoryId}&page=${page}&per_page=${perPage}&_embed`);
  return z.array(PostSchema).parse(data);
};