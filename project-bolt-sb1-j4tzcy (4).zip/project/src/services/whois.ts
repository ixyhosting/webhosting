import { z } from 'zod';

const WhoisResponseSchema = z.object({
  available: z.boolean(),
  domain: z.string(),
  status: z.array(z.string()).optional(),
  created_date: z.string().optional(),
  expiry_date: z.string().optional(),
  registrar: z.string().optional(),
});

type WhoisResponse = z.infer<typeof WhoisResponseSchema>;

// Simulate domain availability with consistent results
const simulateDomainAvailability = (domain: string): boolean => {
  const hash = domain.split('').reduce((acc, char) => {
    return char.charCodeAt(0) + ((acc << 5) - acc);
  }, 0);
  return hash % 2 === 0;
};

export const checkDomain = async (domain: string): Promise<WhoisResponse> => {
  // If we have an API key, use the real API
  if (import.meta.env.VITE_WHOIS_API_KEY && import.meta.env.VITE_WHOIS_API_KEY !== 'at_YOUR_API_KEY_HERE') {
    try {
      const response = await fetch(`https://domain-availability-api.whoisxmlapi.com/api/v1?apiKey=${import.meta.env.VITE_WHOIS_API_KEY}&domainName=${domain}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch domain information');
      }

      const data = await response.json();
      return WhoisResponseSchema.parse({
        available: data.DomainInfo.domainAvailability === 'AVAILABLE',
        domain: domain,
        status: data.DomainInfo.status,
        created_date: data.DomainInfo.createdDate,
        expiry_date: data.DomainInfo.expiryDate,
        registrar: data.DomainInfo.registrar
      });
    } catch (error) {
      console.error('WHOIS API Error:', error);
      // Fall back to simulation if API fails
      return simulateResponse(domain);
    }
  }

  // If no API key, use simulation
  return simulateResponse(domain);
};

const simulateResponse = async (domain: string): Promise<WhoisResponse> => {
  // Add artificial delay to simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));

  const available = simulateDomainAvailability(domain);
  
  if (available) {
    return {
      available: true,
      domain: domain,
      status: ['AVAILABLE'],
    };
  }

  const registrationDate = new Date();
  registrationDate.setFullYear(registrationDate.getFullYear() - 1);
  
  const expiryDate = new Date();
  expiryDate.setFullYear(expiryDate.getFullYear() + 1);

  return {
    available: false,
    domain: domain,
    status: ['registered'],
    created_date: registrationDate.toISOString(),
    expiry_date: expiryDate.toISOString(),
    registrar: 'Sample Registrar, Inc.',
  };
};