/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_WHMCS_API_URL: string
  readonly VITE_WHMCS_IDENTIFIER: string
  readonly VITE_WHMCS_SECRET: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}