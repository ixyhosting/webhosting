import React, { createContext, useContext, useState, useEffect } from 'react';

type Currency = {
  code: string;
  symbol: string;
  multiplier: number;
};

type CurrencyContextType = {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
};

const currencies = {
  global: { code: 'USD', symbol: '$', multiplier: 1 },
  india: { code: 'INR', symbol: '₹', multiplier: 82.75 },
};

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency, setCurrency] = useState<Currency>(currencies.global);

  useEffect(() => {
    // Check for currency header set by edge function
    const userCurrency = document.querySelector('meta[name="x-user-currency"]')?.getAttribute('content');
    if (userCurrency === 'INR') {
      setCurrency(currencies.india);
    }
  }, []);

  const handleCurrencyChange = (newCurrency: Currency) => {
    setCurrency(newCurrency);
  };

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency: handleCurrencyChange }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return {
    ...context,
    currencies,
  };
}