import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import HostingPage from './pages/HostingPage';
import SupportPage from './pages/SupportPage';
import DomainPage from './pages/DomainPage';
import BlogPage from './pages/BlogPage';
import WordPressHostingPage from './pages/WordPressHostingPage';
import BlackFridayPage from './pages/BlackFridayPage';
import BlackFridayBanner from './components/BlackFridayBanner';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <BlackFridayBanner />
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/hosting" element={<HostingPage />} />
          <Route path="/support" element={<SupportPage />} />
          <Route path="/domains" element={<DomainPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/wordpress" element={<WordPressHostingPage />} />
          <Route path="/black-friday" element={<BlackFridayPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;