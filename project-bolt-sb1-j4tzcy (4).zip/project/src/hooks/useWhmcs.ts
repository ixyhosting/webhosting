import { useState, useCallback } from 'react';
import { whmcsApi } from '../lib/whmcs';
import type { WhmcsResponse } from '../config/whmcs';

export function useWhmcs() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const executeAction = useCallback(async (
    action: keyof typeof whmcsApi,
    params?: any
  ): Promise<WhmcsResponse | null> => {
    setLoading(true);
    setError(null);

    try {
      const response = await (whmcsApi[action] as any)(params);
      return response;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    executeAction,
  };
}