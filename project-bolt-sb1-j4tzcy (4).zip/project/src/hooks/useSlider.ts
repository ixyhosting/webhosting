import { useState, useEffect, useCallback } from 'react';

export function useSlider(maxIndex: number, interval: number = 3000) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToSlide = useCallback((index: number) => {
    setCurrentIndex(index);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % (maxIndex + 1));
    }, interval);

    return () => clearInterval(timer);
  }, [maxIndex, interval]);

  return {
    currentIndex,
    goToSlide,
  };
}