import { useState, useEffect } from 'react';

export function useCountdownDates() {
  const [dates, setDates] = useState<Date[]>([]);

  useEffect(() => {
    // Base date - November 27, 2024
    const baseDate = new Date('2024-11-27T23:59:59');
    
    // Extended dates
    const extendedDate1 = new Date(baseDate);
    extendedDate1.setDate(baseDate.getDate() + 2);
    
    const extendedDate2 = new Date(baseDate);
    extendedDate2.setDate(baseDate.getDate() + 4);

    setDates([baseDate, extendedDate1, extendedDate2]);
  }, []);

  return dates;
}