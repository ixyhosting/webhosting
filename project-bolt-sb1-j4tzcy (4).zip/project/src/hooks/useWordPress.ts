import { useQuery } from '@tanstack/react-query';
import { getPosts, getPost, getCategories, getPostsByCategory } from '../lib/wordpress';

export function usePosts(page = 1, perPage = 9) {
  return useQuery({
    queryKey: ['posts', page, perPage],
    queryFn: () => getPosts(page, perPage),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

export function usePost(slug: string) {
  return useQuery({
    queryKey: ['post', slug],
    queryFn: () => getPost(slug),
    staleTime: 1000 * 60 * 5,
    enabled: !!slug,
  });
}

export function useCategories() {
  return useQuery({
    queryKey: ['categories'],
    queryFn: getCategories,
    staleTime: 1000 * 60 * 30, // 30 minutes
  });
}

export function usePostsByCategory(categoryId: number | undefined, page = 1, perPage = 9) {
  return useQuery({
    queryKey: ['posts', 'category', categoryId, page, perPage],
    queryFn: () => categoryId ? getPostsByCategory(categoryId, page, perPage) : getPosts(page, perPage),
    staleTime: 1000 * 60 * 5,
  });
}