import React, { useState } from 'react';
import { Search, Check, X, Loader2, ArrowRight } from 'lucide-react';
import { checkDomain } from '../services/whois';
import { useCurrency } from '../contexts/CurrencyContext';

interface DomainResult {
  domain: string;
  available: boolean;
  price: string;
  loading: boolean;
  registrar?: string;
  createdDate?: string;
  expiryDate?: string;
  error?: string;
}

const DomainSearch: React.FC = () => {
  const [domainName, setDomainName] = useState('');
  const [searchResults, setSearchResults] = useState<DomainResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { currency } = useCurrency();

  const formatPrice = (price: number) => {
    if (currency.code === 'INR') {
      const inrPrice = price * currency.multiplier;
      return `${currency.symbol}${Math.round(inrPrice)}`;
    }
    return `$${price.toFixed(2)}`;
  };

  const tlds = [
    { extension: '.com', basePrice: 9.99 },
    { extension: '.net', basePrice: 11.99 },
    { extension: '.org', basePrice: 12.99 },
    { extension: '.io', basePrice: 39.99 },
  ];

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domainName.trim()) {
      setError('Please enter a domain name');
      return;
    }

    setIsSearching(true);
    setSearchResults([]);
    setError(null);

    try {
      const results = await Promise.all(
        tlds.map(async (tld) => {
          const domain = `${domainName.toLowerCase().trim()}${tld.extension}`;
          try {
            const whoisData = await checkDomain(domain);
            return {
              domain,
              available: whoisData.available,
              price: formatPrice(tld.basePrice),
              loading: false,
              registrar: whoisData.registrar,
              createdDate: whoisData.created_date,
              expiryDate: whoisData.expiry_date,
            };
          } catch (err) {
            return {
              domain,
              available: false,
              price: formatPrice(tld.basePrice),
              loading: false,
              error: 'Failed to check availability',
            };
          }
        })
      );

      setSearchResults(results);
    } catch (error) {
      setError('An error occurred while searching. Please try again.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleRegister = (domain: string) => {
    window.open(`https://ixyhosting.com/whmcs/cart.php?a=add&domain=register&query=${domain}`, '_blank');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6">
      <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={domainName}
            onChange={(e) => setDomainName(e.target.value)}
            placeholder="Enter your domain name"
            className="w-full px-4 sm:px-6 py-3 sm:py-4 text-base sm:text-lg border border-gray-300 rounded-lg sm:rounded-l-full focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={isSearching || !domainName.trim()}
            className="flex-1 sm:flex-none px-6 sm:px-8 py-3 sm:py-4 bg-indigo-600 text-white rounded-lg sm:rounded-none hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSearching ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Search className="h-5 w-5" />
            )}
            <span>Search</span>
          </button>
          <button
            type="button"
            onClick={() => handleRegister(domainName)}
            disabled={!domainName.trim()}
            className="flex-1 sm:flex-none px-6 sm:px-8 py-3 sm:py-4 bg-green-600 text-white rounded-lg sm:rounded-r-full hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <span>Register</span>
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </form>

      {error && (
        <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg">
          {error}
        </div>
      )}

      {searchResults.length > 0 && (
        <div className="mt-8 space-y-4">
          {searchResults.map((result) => (
            <div
              key={result.domain}
              className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-white rounded-lg shadow gap-4"
            >
              <div className="flex items-center gap-3">
                {result.error ? (
                  <X className="h-5 w-5 text-yellow-500 flex-shrink-0" />
                ) : result.available ? (
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                ) : (
                  <X className="h-5 w-5 text-red-500 flex-shrink-0" />
                )}
                <div>
                  <p className="font-medium break-all">{result.domain}</p>
                  <p className="text-sm text-gray-500">
                    {result.error ? 'Status unavailable' : result.available ? 'Available' : 'Not Available'}
                    {result.registrar && ` • ${result.registrar}`}
                  </p>
                  {!result.available && result.expiryDate && (
                    <p className="text-xs text-gray-400">
                      Expires: {new Date(result.expiryDate).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between sm:justify-end gap-4">
                <span className="text-lg font-semibold">{result.price}/yr</span>
                {!result.error && result.available && (
                  <button 
                    onClick={() => handleRegister(result.domain)}
                    className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors whitespace-nowrap"
                  >
                    Register
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6 flex flex-wrap justify-center gap-3">
        {tlds.map((tld) => (
          <span key={tld.extension} className="px-3 py-1.5 bg-gray-100 rounded-full text-gray-600 text-sm">
            {tld.extension} {formatPrice(tld.basePrice)}/yr
          </span>
        ))}
      </div>
    </div>
  );
};

export default DomainSearch;