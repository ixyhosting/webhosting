import React from 'react';
import { Globe, MapPin } from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';

export default function CurrencySwitch() {
  const { currency, setCurrency, currencies } = useCurrency();

  const handleGlobalClick = () => {
    setCurrency(currencies.global);
  };

  const handleIndiaClick = () => {
    setCurrency(currencies.india);
  };

  return (
    <div className="flex items-center space-x-4">
      <button
        onClick={handleGlobalClick}
        className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm ${
          currency.code === 'USD'
            ? 'bg-indigo-100 text-indigo-600'
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        <Globe className="h-4 w-4" />
        <span>Global</span>
      </button>
      <button
        onClick={handleIndiaClick}
        className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm ${
          currency.code === 'INR'
            ? 'bg-indigo-100 text-indigo-600'
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        <MapPin className="h-4 w-4" />
        <span>India</span>
      </button>
    </div>
  );
}