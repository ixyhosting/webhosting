import React, { useState } from 'react';
import { Save, Key } from 'lucide-react';

const WhmcsConfig: React.FC = () => {
  const [config, setConfig] = useState({
    apiUrl: '',
    identifier: '',
    secret: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Save configuration to environment variables or secure storage
    console.log('WHMCS Configuration:', config);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-3 mb-6">
        <Key className="h-6 w-6 text-indigo-600" />
        <h2 className="text-xl font-semibold">WHMCS Configuration</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            API URL
          </label>
          <input
            type="url"
            value={config.apiUrl}
            onChange={(e) => setConfig({ ...config, apiUrl: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="https://your-whmcs-instance.com/includes/api.php"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            API Identifier
          </label>
          <input
            type="text"
            value={config.identifier}
            onChange={(e) => setConfig({ ...config, identifier: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter your API identifier"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            API Secret
          </label>
          <input
            type="password"
            value={config.secret}
            onChange={(e) => setConfig({ ...config, secret: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter your API secret"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
        >
          <Save className="h-4 w-4" />
          <span>Save Configuration</span>
        </button>
      </form>
    </div>
  );
};

export default WhmcsConfig;