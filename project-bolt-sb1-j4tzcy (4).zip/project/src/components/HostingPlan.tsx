import React from 'react';
import { ArrowRight } from 'lucide-react';

interface HostingPlanProps {
  name: string;
  description: string;
  storage: string;
  bandwidth: string;
  domains: string;
  price: string;
}

export default function HostingPlan({ name, description, storage, bandwidth, domains, price }: HostingPlanProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-bold text-gray-900">{name}</h3>
          <p className="text-gray-600 text-sm mt-1">{description}</p>
        </div>
        <span className="text-2xl font-bold text-indigo-600">{price}</span>
      </div>
      
      <div className="space-y-3 mb-6">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Storage</span>
          <span className="font-medium text-gray-900">{storage}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Bandwidth</span>
          <span className="font-medium text-gray-900">{bandwidth}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Domains</span>
          <span className="font-medium text-gray-900">{domains}</span>
        </div>
      </div>

      <button className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white py-2 rounded-lg hover:from-indigo-700 hover:to-indigo-800 transition-colors">
        <span>Select Plan</span>
        <ArrowRight className="h-4 w-4" />
      </button>
    </div>
  );
}