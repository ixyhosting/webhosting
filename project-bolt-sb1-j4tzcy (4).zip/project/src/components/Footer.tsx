import React from 'react';
import { Link } from 'react-router-dom';
import { Server, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12 px-4">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center mb-4">
            <Server className="h-8 w-8 text-indigo-500" />
            <span className="ml-2 text-xl font-bold text-white">IXYHosting</span>
          </div>
          <p className="text-sm">Empowering businesses with reliable cloud hosting solutions since 2024.</p>
        </div>
        <div>
          <h3 className="text-white font-semibold mb-4">Product</h3>
          <ul className="space-y-2">
            <li><Link to="/domains" className="hover:text-white transition-colors">Domains</Link></li>
            <li><Link to="/hosting" className="hover:text-white transition-colors">Web Hosting</Link></li>
            <li><Link to="/hosting" className="hover:text-white transition-colors">WordPress Hosting</Link></li>
            <li><Link to="/hosting" className="hover:text-white transition-colors">VPS Hosting</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-white font-semibold mb-4">Company</h3>
          <ul className="space-y-2">
            <li><Link to="/about" className="hover:text-white transition-colors">About</Link></li>
            <li><Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
            <li><Link to="/terms" className="hover:text-white transition-colors">Terms & Conditions</Link></li>
            <li><Link to="/refund-policy" className="hover:text-white transition-colors">Refund Policy</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-white font-semibold mb-4">Support</h3>
          <ul className="space-y-2">
            <li>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>support@ixyhosting.com</span>
              </div>
            </li>
            <li>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>Palnadu, India, 522601</span>
              </div>
            </li>
            <li><Link to="/support" className="hover:text-white transition-colors">Help Center</Link></li>
            <li><a href="https://status.ixyhosting.com" className="hover:text-white transition-colors">System Status</a></li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-8 pt-8 border-t border-gray-800">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm">&copy; {new Date().getFullYear()} IXYHosting. All rights reserved.</p>
          <div className="flex gap-6 text-sm">
            <Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
            <Link to="/refund-policy" className="hover:text-white transition-colors">Refund Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;