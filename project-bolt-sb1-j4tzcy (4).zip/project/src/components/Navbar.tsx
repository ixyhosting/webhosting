import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Server, Menu, X, HeadphonesIcon } from 'lucide-react';
import CurrencySwitch from './CurrencySwitch';
import PromotionalPopup from './PromotionalPopup';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showPromo, setShowPromo] = useState(false);

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'Domains', href: '/domains' },
    { name: 'Hosting', href: '/hosting' },
    { name: 'WordPress', href: '/wordpress' },
    { name: 'Blog', href: '/blog' },
  ];

  useEffect(() => {
    // Show promotional popup after 2 seconds
    const timer = setTimeout(() => {
      setShowPromo(true);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <nav className="fixed w-full bg-blue-50/80 backdrop-blur-md z-50 border-b border-blue-100">
      <PromotionalPopup isVisible={showPromo} onClose={() => setShowPromo(false)} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <Server className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500">
              IXYHosting
            </span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-gray-600 hover:text-indigo-600 transition-colors"
              >
                {item.name}
              </Link>
            ))}
            <CurrencySwitch />
            <div className="flex items-center space-x-4 ml-4 pl-6 border-l border-gray-200">
              <a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-600 hover:text-indigo-600 transition-colors font-medium"
              >
                <HeadphonesIcon className="h-5 w-5" />
                Support
              </a>
              <a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-indigo-600 text-white px-6 py-2 rounded-full hover:bg-indigo-700 transition-colors"
              >
                Get Started
              </a>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="text-gray-600 hover:text-gray-900 focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-b">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="block px-3 py-2 text-gray-600 hover:text-indigo-600 hover:bg-gray-50 rounded-md"
                onClick={() => setIsOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <div className="px-3 py-2">
              <CurrencySwitch />
            </div>
            <div className="px-3 py-3 space-y-2 border-t border-gray-100 mt-2">
              <a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-indigo-600 hover:bg-gray-50 rounded-md"
              >
                <HeadphonesIcon className="h-5 w-5" />
                Support
              </a>
              <a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-indigo-600 text-white px-6 py-2 rounded-full hover:bg-indigo-700 text-center"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;