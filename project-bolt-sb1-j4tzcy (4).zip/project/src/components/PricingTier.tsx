import React from 'react';
import { Check, LucideIcon, Timer } from 'lucide-react';

interface PricingTierProps {
  name: string;
  description: string;
  price: string;
  originalPrice: string;
  features: string[];
  highlighted?: boolean;
  icon: LucideIcon;
}

const PricingTier: React.FC<PricingTierProps> = ({
  name,
  description,
  price,
  originalPrice,
  features,
  highlighted = false,
  icon: Icon,
}) => {
  return (
    <div
      className={`rounded-2xl p-8 transition-transform hover:scale-105 ${
        highlighted
          ? 'bg-gradient-to-b from-indigo-600 to-indigo-700 text-white shadow-xl'
          : 'bg-white shadow-lg'
      }`}
    >
      {/* Black Friday Badge */}
      <div className="absolute -top-4 right-4">
        <div className="bg-black text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
          <Timer className="h-3 w-3" />
          BLACK FRIDAY
        </div>
      </div>

      <div className="flex items-center gap-3 mb-6">
        <Icon className={`h-8 w-8 ${highlighted ? 'text-indigo-200' : 'text-indigo-600'}`} />
        <div>
          <h3 className="text-2xl font-bold">{name}</h3>
          <p className={highlighted ? 'text-indigo-200' : 'text-gray-600'}>{description}</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm line-through opacity-70">{originalPrice}/mo</span>
          <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">-80%</span>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-4xl font-bold">{price}</span>
          <span className={highlighted ? 'text-indigo-200' : 'text-gray-500'}>/month</span>
        </div>
        <div className="mt-1 text-sm text-emerald-500 font-medium">+ 3 Months Free</div>
      </div>

      <ul className="space-y-4 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start gap-3">
            <Check className={`h-5 w-5 mt-0.5 ${highlighted ? 'text-indigo-200' : 'text-indigo-600'}`} />
            <span className={highlighted ? 'text-indigo-100' : 'text-gray-600'}>{feature}</span>
          </li>
        ))}
      </ul>

      <a
        href="https://ixyhosting.com/whmcs/"
        target="_blank"
        rel="noopener noreferrer"
        className={`block w-full py-3 px-6 rounded-full text-center font-medium transition-colors ${
          highlighted
            ? 'bg-white text-indigo-600 hover:bg-gray-100'
            : 'bg-indigo-600 text-white hover:bg-indigo-700'
        }`}
      >
        Claim Deal Now
      </a>

      <p className="text-center mt-4 text-sm opacity-70">
        Offer ends November 27, 2024
      </p>
    </div>
  );
};

export default PricingTier;