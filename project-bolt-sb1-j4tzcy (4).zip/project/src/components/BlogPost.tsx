import React from 'react';
import { usePost } from '../hooks/useWordPress';
import { Loader2, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

interface BlogPostProps {
  slug: string;
}

const BlogPost: React.FC<BlogPostProps> = ({ slug }) => {
  const { data: post, isLoading, error } = usePost(slug);

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="text-center p-8">
        <p className="text-red-600">Error loading post</p>
        <Link to="/blog" className="text-indigo-600 hover:text-indigo-700 mt-4 inline-block">
          Return to Blog
        </Link>
      </div>
    );
  }

  return (
    <article>
      <Link 
        to="/blog"
        className="inline-flex items-center text-indigo-600 hover:text-indigo-700 mb-8"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Blog
      </Link>
      
      <div className="prose prose-lg max-w-none">
        <h1 
          className="text-4xl font-bold mb-4"
          dangerouslySetInnerHTML={{ __html: post.title.rendered }} 
        />
        <div className="text-sm text-gray-500 mb-8">
          Published on {new Date(post.date).toLocaleDateString()}
        </div>
        <div 
          className="mt-8"
          dangerouslySetInnerHTML={{ __html: post.content.rendered }} 
        />
      </div>
    </article>
  );
};

export default BlogPost;