import React from 'react';
import { useWhmcs } from '../hooks/useWhmcs';
import { Server, ShoppingCart, CreditCard } from 'lucide-react';

const WhmcsIntegration: React.FC = () => {
  const { loading, executeAction } = useWhmcs();

  const handleOrderProduct = async (productId: number) => {
    try {
      await executeAction('createOrder', {
        clientid: 1, // Replace with actual client ID
        pid: productId,
        billingcycle: 'monthly'
      });
    } catch (error) {
      console.error('Order creation failed:', error);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-4 mb-6">
        <Server className="h-8 w-8 text-indigo-600" />
        <div>
          <h3 className="text-xl font-bold">WHMCS Integration</h3>
          <p className="text-gray-600">Manage your hosting services</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="p-4 border border-gray-200 rounded-lg">
          <ShoppingCart className="h-6 w-6 text-indigo-600 mb-3" />
          <h4 className="font-semibold mb-2">Order Management</h4>
          <p className="text-sm text-gray-600 mb-4">
            View and manage your hosting orders
          </p>
          <button 
            className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors"
            disabled={loading}
          >
            View Orders
          </button>
        </div>

        <div className="p-4 border border-gray-200 rounded-lg">
          <CreditCard className="h-6 w-6 text-indigo-600 mb-3" />
          <h4 className="font-semibold mb-2">Billing & Invoices</h4>
          <p className="text-sm text-gray-600 mb-4">
            Access your billing information
          </p>
          <button 
            className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors"
            disabled={loading}
          >
            View Invoices
          </button>
        </div>
      </div>
    </div>
  );
};

export default WhmcsIntegration;