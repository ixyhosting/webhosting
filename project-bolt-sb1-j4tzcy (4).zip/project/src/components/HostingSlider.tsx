import React from 'react';
import { useSlider } from '../hooks/useSlider';
import { Server, Database, Globe2, Monitor, Cloud, Shield } from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';

const HostingSlider: React.FC = () => {
  const maxVisibleSlides = 3;
  const { currency } = useCurrency();

  const formatPrice = (price: number) => {
    if (currency.code === 'INR') {
      return `${currency.symbol}${Math.round(price * currency.multiplier)}`;
    }
    return `$${price.toFixed(2)}`;
  };

  const allPlans = [
    {
      icon: Server,
      name: 'Personal Hosting',
      description: 'Perfect for small websites',
      storage: '10GB SSD',
      bandwidth: '100GB',
      domains: '1 Website',
      originalPrice: 14.99,
      price: 2.99,
      features: [
        '1 Website',
        '10 GB SSD Raid Storage',
        'Up to 25K Monthly Visitors',
        'Free SPanel',
        'Automatic Malware Scans'
      ],
      category: 'hosting'
    },
    {
      icon: Database,
      name: 'Business Hosting',
      description: 'Ideal for growing businesses',
      storage: '50GB SSD',
      bandwidth: 'Unlimited',
      domains: '100 Websites',
      originalPrice: 29.99,
      price: 5.99,
      features: [
        '100 Websites',
        '30 GB SSD Raid Storage',
        'Up to 50K Monthly Visitors',
        'Unlimited Bandwidth',
        'Unlimited Mail Accounts'
      ],
      category: 'hosting',
      highlighted: true
    },
    {
      icon: Globe2,
      name: 'Enterprise Hosting',
      description: 'For high-traffic websites',
      storage: '100GB SSD',
      bandwidth: 'Unlimited',
      domains: '300 Websites',
      originalPrice: 49.99,
      price: 9.99,
      features: [
        '300 Websites',
        '100 GB SSD Storage',
        'Up to 100K Monthly Visitors',
        'Website Backup Protection',
        'Automatic Malware Scans',
        'Free Domain'
      ],
      category: 'hosting'
    },
    {
      icon: Monitor,
      name: 'WordPress Basic',
      description: 'WordPress optimized hosting',
      storage: '25GB SSD',
      bandwidth: '250GB',
      domains: '2 Websites',
      originalPrice: 24.99,
      price: 4.99,
      features: [
        '2 Websites',
        '25 GB SSD Storage',
        'WordPress Optimization',
        'Free SSL Certificate',
        'Daily Backups'
      ],
      category: 'wordpress'
    },
    {
      icon: Cloud,
      name: 'WordPress Pro',
      description: 'Advanced WordPress solution',
      storage: '75GB SSD',
      bandwidth: 'Unlimited',
      domains: '10 Websites',
      originalPrice: 44.99,
      price: 8.99,
      features: [
        '10 Websites',
        '75 GB SSD Storage',
        'Advanced Caching',
        'Staging Environment',
        'Priority Support'
      ],
      category: 'wordpress',
      highlighted: true
    },
    {
      icon: Shield,
      name: 'WordPress Enterprise',
      description: 'Enterprise WordPress hosting',
      storage: '150GB SSD',
      bandwidth: 'Unlimited',
      domains: 'Unlimited',
      originalPrice: 74.99,
      price: 14.99,
      features: [
        'Unlimited Websites',
        '150 GB SSD Storage',
        'Advanced Security',
        'Dedicated Resources',
        'Enterprise Support'
      ],
      category: 'wordpress'
    }
  ];

  const { currentIndex, goToSlide } = useSlider(Math.ceil(allPlans.length / maxVisibleSlides) - 1);

  return (
    <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-block mb-6 bg-black/10 backdrop-blur-sm px-6 py-2 rounded-full text-indigo-600 font-semibold">
            🔥 BLACK FRIDAY SALE: 80% OFF + 3 MONTHS FREE
          </div>
          <h2 className="text-3xl font-bold mb-4">Choose Your Plan</h2>
          <p className="text-gray-600">All plans include free SSL, daily backups, and 24/7 support</p>
        </div>

        {/* Desktop Slider */}
        <div className="hidden md:block relative">
          <div
            className="flex transition-transform duration-500 ease-in-out"
            style={{
              transform: `translateX(-${(currentIndex * 100) / maxVisibleSlides}%)`,
            }}
          >
            {allPlans.map((plan, index) => (
              <div
                key={index}
                className="w-1/3 flex-shrink-0 px-4"
                style={{ minWidth: `${100 / maxVisibleSlides}%` }}
              >
                <div className={`relative bg-white rounded-2xl p-8 h-full transform hover:scale-105 transition-all duration-300 ${
                  plan.highlighted ? 'shadow-2xl ring-2 ring-indigo-600' : 'shadow-xl'
                }`}>
                  {plan.highlighted && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                        Most Popular
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                      <p className="text-gray-600 mt-1">{plan.description}</p>
                    </div>
                    <plan.icon className="h-12 w-12 text-indigo-600" />
                  </div>

                  <div className="mb-6">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm line-through opacity-70">
                        {formatPrice(plan.originalPrice)}/mo
                      </span>
                      <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                        -80%
                      </span>
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold text-indigo-600">
                        {formatPrice(plan.price)}
                      </span>
                      <span className="text-gray-500">/month</span>
                    </div>
                    <div className="mt-1 text-sm text-emerald-500 font-medium">
                      + 3 Months Free
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-gray-600">
                        <span className="h-1.5 w-1.5 bg-indigo-600 rounded-full mr-2"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <a
                    href="https://ixyhosting.com/whmcs/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors text-center"
                  >
                    Claim Deal Now
                  </a>

                  <p className="text-center mt-4 text-sm text-gray-500">
                    Offer ends November 27, 2024
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Dots */}
          <div className="flex justify-center space-x-2 mt-8">
            {Array.from({ length: Math.ceil(allPlans.length / maxVisibleSlides) }).map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`h-2 w-2 rounded-full transition-colors ${
                  currentIndex === index ? 'bg-indigo-600' : 'bg-gray-300'
                }`}
                aria-label={`Go to slide group ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Mobile View */}
        <div className="md:hidden space-y-6">
          {allPlans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-2xl p-6 ${
                plan.highlighted ? 'shadow-2xl ring-2 ring-indigo-600' : 'shadow-xl'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
                  <p className="text-gray-600 text-sm mt-1">{plan.description}</p>
                </div>
                <plan.icon className="h-10 w-10 text-indigo-600" />
              </div>

              <div className="mb-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm line-through opacity-70">
                    {formatPrice(plan.originalPrice)}/mo
                  </span>
                  <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                    -80%
                  </span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold text-indigo-600">
                    {formatPrice(plan.price)}
                  </span>
                  <span className="text-gray-500">/month</span>
                </div>
                <div className="mt-1 text-sm text-emerald-500 font-medium">
                  + 3 Months Free
                </div>
              </div>

              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-600 text-sm">
                    <span className="h-1.5 w-1.5 bg-indigo-600 rounded-full mr-2"></span>
                    {feature}
                  </li>
                ))}
              </ul>

              <a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-indigo-600 text-white py-2.5 rounded-lg hover:bg-indigo-700 transition-colors text-center"
              >
                Claim Deal Now
              </a>

              <p className="text-center mt-4 text-xs text-gray-500">
                Offer ends November 27, 2024
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HostingSlider;