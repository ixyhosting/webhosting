import React from 'react';
import { useCategories } from '../hooks/useWordPress';
import { Loader2 } from 'lucide-react';

interface BlogCategoriesProps {
  onSelect: (categoryId: number) => void;
  selectedCategory?: number;
}

const BlogCategories: React.FC<BlogCategoriesProps> = ({ onSelect, selectedCategory }) => {
  const { categories, isLoading, error } = useCategories();

  if (isLoading) {
    return <Loader2 className="h-5 w-5 text-indigo-600 animate-spin" />;
  }

  if (error || !categories) {
    return null;
  }

  return (
    <div className="flex flex-wrap gap-2 mb-6">
      {categories.map((category: any) => (
        <button
          key={category.id}
          onClick={() => onSelect(category.id)}
          className={`px-4 py-2 rounded-full text-sm ${
            selectedCategory === category.id
              ? 'bg-indigo-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {category.name}
        </button>
      ))}
    </div>
  );
};

export default BlogCategories;