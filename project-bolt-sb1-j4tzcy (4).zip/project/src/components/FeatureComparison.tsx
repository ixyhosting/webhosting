import React from 'react';
import { Check, Minus } from 'lucide-react';

interface Plan {
  name: string;
  features: string[];
}

interface FeatureComparisonProps {
  plans: Plan[];
}

const FeatureComparison: React.FC<FeatureComparisonProps> = ({ plans }) => {
  // Define all features with their categories
  const featureCategories = {
    'Performance': [
      'NVMe SSD Storage',
      'Redis Cache',
      'Global CDN',
      'HTTP/3 Support',
      'PHP 8.x Support',
      'Unlimited Bandwidth',
    ],
    'Security': [
      'Daily Backups',
      'Malware Scanning',
      'Web Application Firewall',
      'DDoS Protection',
      'IP Blocking',
      'SSL Manager',
    ],
    'WordPress Tools': [
      'WordPress Auto-updates',
      'Staging Environment',
      '1-Click WordPress Install',
      'WP-CLI Access',
      'Git Integration',
      'WordPress Multisite',
    ],
    'Support': [
      '24/7 Support',
      'Priority Support',
      'WordPress Expert Support',
      'Phone Support',
      'Live Chat',
      'Knowledge Base Access',
    ],
  };

  // Helper function to check if a feature is included in a plan
  const hasFeature = (planName: string, feature: string): boolean => {
    const plan = plans.find(p => p.name === planName);
    if (!plan) return false;
    return plan.features.some(f => f.includes(feature));
  };

  return (
    <section className="py-20 px-4 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Feature Comparison</h2>
          <p className="text-gray-600">Detailed comparison of all features included in each plan</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full bg-white rounded-xl shadow-lg">
            <thead>
              <tr className="bg-gray-50">
                <th className="py-4 px-6 text-left font-semibold text-gray-900 w-1/3">Features</th>
                {plans.map((plan) => (
                  <th key={plan.name} className="py-4 px-6 text-center font-semibold text-gray-900">
                    {plan.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Object.entries(featureCategories).map(([category, features]) => (
                <React.Fragment key={category}>
                  <tr className="bg-indigo-50">
                    <td colSpan={plans.length + 1} className="py-3 px-6 font-semibold text-indigo-900">
                      {category}
                    </td>
                  </tr>
                  {features.map((feature, featureIndex) => (
                    <tr
                      key={feature}
                      className={featureIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}
                    >
                      <td className="py-4 px-6 text-gray-700">{feature}</td>
                      {plans.map((plan) => (
                        <td key={`${plan.name}-${feature}`} className="py-4 px-6 text-center">
                          {hasFeature(plan.name, feature) ? (
                            <Check className="h-5 w-5 text-green-500 mx-auto" />
                          ) : (
                            <Minus className="h-5 w-5 text-gray-300 mx-auto" />
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          * All plans include our 30-day money-back guarantee and 99.9% uptime guarantee
        </div>
      </div>
    </section>
  );
};

export default FeatureComparison;