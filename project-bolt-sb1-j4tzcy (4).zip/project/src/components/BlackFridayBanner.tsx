import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import CountdownTimer from './CountdownTimer';
import { useCountdownDates } from '../hooks/useCountdownDates';

const BlackFridayBanner: React.FC = () => {
  const countdownDates = useCountdownDates();

  return (
    <div className="bg-gradient-to-r from-gray-900 via-indigo-900 to-purple-900 text-white py-4 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxIDAgNiAyLjY5IDYgNnMtMi42OSA2LTYgNi02LTIuNjktNi02IDIuNjktNiA2LTZ6bTAgMmMtMi4yMSAwLTQgMS43OS00IDRzMS43OSA0IDQgNCA0LTEuNzkgNC00LTEuNzktNC00LTR6IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-10" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-yellow-400 animate-pulse" />
            <span className="font-bold text-lg">BLACK FRIDAY MEGA SALE</span>
          </div>
          
          {countdownDates[0] && (
            <div className="flex items-center gap-2 bg-black/20 px-4 py-1 rounded-full">
              <CountdownTimer 
                endDate={countdownDates[0]} 
                variant="minimal" 
              />
            </div>
          )}
          
          <div className="flex items-center gap-2">
            <span className="font-medium">Save up to 80% + Get 3 Months FREE!</span>
            <Link 
              to="/black-friday" 
              className="flex items-center gap-1 bg-white text-indigo-900 px-4 py-1 rounded-full hover:bg-indigo-100 transition-colors font-medium"
            >
              Claim Now <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlackFridayBanner;