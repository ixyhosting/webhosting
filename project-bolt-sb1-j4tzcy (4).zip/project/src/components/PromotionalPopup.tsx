import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles } from 'lucide-react';
import CountdownTimer from './CountdownTimer';
import { useCountdownDates } from '../hooks/useCountdownDates';

interface PromotionalPopupProps {
  isVisible: boolean;
  onClose: () => void;
}

const PromotionalPopup: React.FC<PromotionalPopupProps> = ({ isVisible, onClose }) => {
  const countdownDates = useCountdownDates();

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -20, rotateX: 45 }}
          animate={{ 
            opacity: 1, 
            y: 0, 
            rotateX: 0,
            transition: { 
              type: "spring",
              stiffness: 300,
              damping: 20
            }
          }}
          exit={{ opacity: 0, y: -20, rotateX: 45 }}
          className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50"
        >
          <div className="relative bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 rounded-xl shadow-2xl">
            <button
              onClick={onClose}
              className="absolute -top-2 -right-2 bg-white text-gray-900 rounded-full p-1 shadow-lg hover:bg-gray-100 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="text-center">
              <motion.div
                animate={{ 
                  y: [0, -5, 0],
                  rotateZ: [-1, 1, -1]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="relative"
              >
                <div className="absolute inset-0 bg-white/20 blur-xl rounded-full transform -translate-y-1/2" />
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Sparkles className="h-5 w-5 text-yellow-400" />
                  <h3 className="text-xl font-bold">BLACK FRIDAY SALE!</h3>
                </div>
              </motion.div>
              
              <p className="mb-4">
                Save up to 80% on all plans<br />
                <span className="text-emerald-300">+ Get 3 Months FREE!</span>
              </p>

              {countdownDates[0] && (
                <div className="mb-4">
                  <CountdownTimer 
                    endDate={countdownDates[0]} 
                    variant="secondary"
                    label="Offer Ends In"
                  />
                </div>
              )}
              
              <motion.a
                href="https://ixyhosting.com/whmcs/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-white text-indigo-600 px-6 py-2 rounded-full font-medium hover:bg-gray-100 transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Claim Now
              </motion.a>
            </div>

            {/* 3D Effect Shadows */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent rounded-xl transform rotate-3 -z-10 blur-sm" />
            <div className="absolute inset-0 bg-gradient-to-l from-black/20 to-transparent rounded-xl transform -rotate-3 -z-10 blur-sm" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PromotionalPopup;