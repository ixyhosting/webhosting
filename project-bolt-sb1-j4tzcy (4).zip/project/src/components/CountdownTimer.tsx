import React, { useState, useEffect } from 'react';
import { Timer } from 'lucide-react';

interface CountdownTimerProps {
  endDate: Date;
  label?: string;
  variant?: 'primary' | 'secondary' | 'minimal';
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ 
  endDate, 
  label = "Limited Time Offer", 
  variant = 'primary' 
}) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = endDate.getTime() - new Date().getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [endDate]);

  if (variant === 'minimal') {
    return (
      <div className="flex items-center gap-2 text-sm">
        <Timer className="h-4 w-4 animate-pulse" />
        <span>
          {timeLeft.days}d {timeLeft.hours}h {timeLeft.minutes}m {timeLeft.seconds}s
        </span>
      </div>
    );
  }

  const timeBlocks = [
    { label: 'Days', value: timeLeft.days },
    { label: 'Hours', value: timeLeft.hours },
    { label: 'Minutes', value: timeLeft.minutes },
    { label: 'Seconds', value: timeLeft.seconds }
  ];

  return (
    <div className={`rounded-lg ${variant === 'secondary' ? 'bg-gray-800' : 'bg-gradient-to-r from-indigo-600 to-purple-600'} p-4 shadow-lg`}>
      <div className="text-center mb-2">
        <span className={`font-medium ${variant === 'secondary' ? 'text-indigo-400' : 'text-white'}`}>
          {label}
        </span>
      </div>
      <div className="flex justify-center gap-3">
        {timeBlocks.map(({ label, value }) => (
          <div 
            key={label} 
            className={`${
              variant === 'secondary' ? 'bg-gray-700' : 'bg-black/20 backdrop-blur-sm'
            } px-3 py-2 rounded`}
          >
            <div className={`${
              variant === 'secondary' ? 'text-xl' : 'text-2xl'
            } font-bold text-white`}>
              {String(value).padStart(2, '0')}
            </div>
            <div className={`text-xs ${
              variant === 'secondary' ? 'text-gray-400' : 'text-indigo-200'
            }`}>
              {label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CountdownTimer;