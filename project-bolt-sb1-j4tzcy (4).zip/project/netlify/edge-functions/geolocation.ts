import { Context } from 'https://edge.netlify.com';

export default async (request: Request, context: Context) => {
  // Get user's country from Netlify's geolocation data
  const country = context.geo?.country?.code || 'US';
  
  // Set default currency based on location
  const currency = country === 'IN' ? 'INR' : 'USD';
  
  // Add currency info to request headers
  const response = await context.next();
  response.headers.set('X-User-Currency', currency);
  response.headers.set('X-User-Country', country);
  
  return response;
};